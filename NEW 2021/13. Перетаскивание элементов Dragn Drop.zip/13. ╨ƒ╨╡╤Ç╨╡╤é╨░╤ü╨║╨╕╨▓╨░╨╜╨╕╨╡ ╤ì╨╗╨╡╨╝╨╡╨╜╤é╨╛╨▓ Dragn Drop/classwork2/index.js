// const fill = document.querySelector('.fill')
// const empties = document.querySelectorAll('.empty')

// // FILL Listeners
// fill.addEventListener('dragstart', dragStart)
// fill.addEventListener('dragend', dragEnd)

// // Loop throught empties and call drag events
// for (let empty of empties) {
//     empty.addEventListener('dragover', dragOver);
//     empty.addEventListener('dragenter', dragEnter);
//     empty.addEventListener('dragleave', dragLeave);
//     empty.addEventListener('drop', dragDrop);
// }

// // Drag functions

// function dragStart (event) {
//     console.log('dragStart');
//     this.className += ' hold';
//     setTimeout(() => (this.className = 'invisible'), 0)
// }

// function dragEnd () {
//     console.log('dragEnd');
//     this.className = 'fill'
// }

// function dragOver (event) {
//     event.preventDefault()
// }
// function  dragEnter (e) {
//     console.log('dragEnter');
//     e.preventDefault()
//     this.className += ' hovered'
// }
// function  dragLeave () {
//     console.log('dragLeave');
//     this.className = 'empty'
// }
// function  dragDrop () {
//     console.log('dragDrop');
//     this.className = 'empty'
//     this.append(fill )
// }

;(() => {
	// const item = document.querySelector('.item');
	const empties = document.querySelectorAll('.empties')

	const fill = document.querySelector('.fill')

	let item

	fill.addEventListener('mousedown', ({ target }) => {
		if (target.closest('.item')) {
			const elem = target.closest('.item')
			elem.addEventListener('dragstart', dragStart)
			elem.addEventListener('dragend', dragEnd)
			item = elem
		}
	})

	// item.addEventListener('dragstart', dragStart);
	// item.addEventListener('dragend', dragEnd);

	for (const placeholder of empties) {
		placeholder.addEventListener('dragover', dragOver)
		placeholder.addEventListener('dragenter', dragEnter)
		placeholder.addEventListener('dragleave', dragLeave)
		placeholder.addEventListener('drop', dragDrop)
	}

	function dragStart({ target }) {
		target.classList.add('hold')
		setTimeout(() => target.classList.add('hide'), 0)
	}

	function dragEnd({ target }) {
		target.classList.remove('hide', 'hold')
	}

	function dragOver(e) {
		e.preventDefault()
	}
	function dragEnter({ target }) {
		target.classList.add('hover')
	}
	function dragLeave({ target }) {
		target.classList.remove('hover')
	}
	function dragDrop({ target }) {
		target.classList.remove('hover')
		target.append(item)
	}
})()
