// 1. Массивы
//     1. Пример `let family = ['Alex', 'Barbara', 'Michael']`
//     2. Выбрать элемент из массивы `family[0]` и из `string[0]`

// 2. Методы массивов

// 1. Добавление  элементов `push() unshift()`
// 2. Удаление `shift() pop() splice()`




