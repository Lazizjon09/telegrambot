// Возвращайте первый элемент из массива

// getFirstValue([1, 2, "null", []]) ➞ 

// getFirstValue(["214", true, false, 2, 2.15, [], null]) ➞ 

// getFirstValue([21.1, "float", "array", ["I am array"],]) ➞



// Возвращайте последний элемент из массива

// getLastItem([1, 2, 3]) ➞ 

// getLastItem(["cat", "dog", "duck"]) ➞ 

// getLastItem([true, false, true]) ➞ 