// STRING

// 1. `toUpperCase() toLowerCase()`
// 2. `slice() length() trim() split(',') replace('a', 'b') concat(a, b)`
// 3. `search() includes()`
// 4. `Выбор символа []`
// 5. `Перевод в Number`

// NUMBER

// 1. `toString() Math.floor() ceil() round()`
// 2. `Math.min() max() Math.pow() Math.random()`
// 3. `parseInt() parseFloat() + Number('1')`
// 4. `toFixed() charAt()`

//Peactise

// 1. let str **=** 'aaa@bbb@ccc';  // заменить @ на !
// 2. сделать из let str1 = "HELLOWORLD" — "Hello world"