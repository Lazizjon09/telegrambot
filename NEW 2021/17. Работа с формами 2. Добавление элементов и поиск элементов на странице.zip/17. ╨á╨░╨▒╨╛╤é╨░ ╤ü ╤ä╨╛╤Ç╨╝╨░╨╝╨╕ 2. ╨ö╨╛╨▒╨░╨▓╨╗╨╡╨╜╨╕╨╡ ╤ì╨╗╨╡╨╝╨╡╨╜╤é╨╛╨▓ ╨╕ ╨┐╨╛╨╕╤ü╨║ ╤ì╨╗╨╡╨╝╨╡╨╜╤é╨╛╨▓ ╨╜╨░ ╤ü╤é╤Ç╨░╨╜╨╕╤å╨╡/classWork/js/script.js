// const products = [
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		brand: 'Acer',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/81Ne5qKmE8L._SL1500_.jpg',
// 		brand: 'ROG',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/nokia-laptop.jpg',
// 		brand: 'Asus',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/u_10214687.jpg',
// 		brand: 'Apple',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		brand: 'hp',
// 		qt: 1,
// 		price: 1000,
// 	},
//     {
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		brand: 'Acer',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/81Ne5qKmE8L._SL1500_.jpg',
// 		brand: 'ROG',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/nokia-laptop.jpg',
// 		brand: 'Asus',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/u_10214687.jpg',
// 		brand: 'Apple',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		brand: 'hp',
// 		qt: 1,
// 		price: 1000,
// 	},
//     {
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		brand: 'Acer',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/81Ne5qKmE8L._SL1500_.jpg',
// 		brand: 'ROG',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/nokia-laptop.jpg',
// 		brand: 'Asus',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/u_10214687.jpg',
// 		brand: 'Apple',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		brand: 'hp',
// 		qt: 1,
// 		price: 1000,
// 	},
//     {
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		brand: 'Acer',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/81Ne5qKmE8L._SL1500_.jpg',
// 		brand: 'ROG',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/nokia-laptop.jpg',
// 		brand: 'Asus',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/u_10214687.jpg',
// 		brand: 'Apple',
// 		qt: 1,
// 		price: 1000,
// 	},
// 	{
// 		id: Math.random(),
// 		typeOfProduct: 'laptop',

// 		description:
// 			'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Saepe sit, et pariatur dignissimos dolorum quibusdam quo culpa harum, explicabo deleniti atque dolorem nam rerum amet cum ullam sint qui voluptas ipsum sequi dicta commodi consequuntur, minima tempore. Nobis repellat deserunt vero in neque amet illum autem dolorum praesentium, beatae, error hic voluptatibus eius, veniam sint. Libero sit omnis, nulla quo tempora aspernatur! Deleniti repellendus fuga, laborum in voluptas corporis qui possimus dolore sunt voluptatibus? Rem iste quod minima ad obcaecati, in dicta aut, aspernatur maxime esse magnam placeat odio nemo sit suscipit culpa autem quibusdam deserunt tempore tempora recusandae et?',
// 		img: './assets/images/61s7sJEpsVL._SY450_.jpg',
// 		brand: 'hp',
// 		qt: 1,
// 		price: 1000,
// 	},
// ]

// for (let item of products) {
// 	let div = document.createElement('div')
// 	let div2 = document.createElement('div')
// 	let span = document.createElement('span')
// 	let img = document.createElement('img')
// 	let p = document.createElement('p')
// 	container.append(div)
// 	div.append(div2)
// 	div2.append(img)
// 	img.after(span)
// 	span.after(p)
// 	div.className = 'item'
// 	div2.className = 'item2'
// 	img.className = 'img'
// 	img.src = item.img
// 	span.innerText = item.brand
// 	p.innerText = item.description
// }

// const requestURL = 'https://jsonplaceholder.typicode.com/users'


// function sendRequest(method, url, body = null) {
//     return new Promise( (resolve, reject) => {
//         const xhr = new XMLHttpRequest()
    
//         xhr.open(method, url)
        
//         xhr.responseType = 'json'
//         xhr.setRequestHeader('Content-Type', 'application/json') 
        
//         xhr.onload = () => {
//             if(xhr.status >= 400) {
//                 reject(xhr.response);
//             } else {
//                 resolve(xhr.response);
//             }
//         }
        
//         xhr.onerror = () => {
//             reject(xhr.response);
//         }
        
//         xhr.send(JSON.stringify(body))
//     }) 
// }

// // sendRequest('GET', requestURL)
// //     .then(data => console.log(data))
// //     .catch(err => console.log(err))

// const body = {
//     name: 'Daler',
//     age: 20
// }

// sendRequest('POST', requestURL,  {
//     name: 'Daler',
//     age: 20
// })
//     .then(data => console.log(data))
//     .catch(err => console.log(err))

const zone1 = document.querySelector('.zone-1')
const zone2 = document.querySelector('.zone-2')
const ufo = document.querySelector('#ufo')

zone1.ondragover = allowDrop
zone2.ondragover = allowDrop

function allowDrop(event) {
    event.preventDefault()
}

ufo.ondragstart = drag

function drag() {
    event.dataTransfer.setData('id', event.target.id);

}
zone1.ondrop = drop;
zone2.ondrop = drop;

function drop(event) {
    let itemId = event.dataTransfer.getData('id');
    console.log(itemId); 
    event.target.append(document.getElementById(itemId))
}