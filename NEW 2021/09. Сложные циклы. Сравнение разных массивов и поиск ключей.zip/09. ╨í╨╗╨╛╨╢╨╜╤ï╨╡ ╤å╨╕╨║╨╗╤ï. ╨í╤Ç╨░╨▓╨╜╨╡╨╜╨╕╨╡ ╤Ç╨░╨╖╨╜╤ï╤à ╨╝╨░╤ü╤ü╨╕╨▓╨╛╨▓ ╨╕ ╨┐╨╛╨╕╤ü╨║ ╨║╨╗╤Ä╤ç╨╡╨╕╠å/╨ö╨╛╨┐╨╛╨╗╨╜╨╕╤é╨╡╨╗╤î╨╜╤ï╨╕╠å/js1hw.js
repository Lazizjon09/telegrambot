let students = [
    {
        name:"Annah",
        mark: "Harvard",
    },
    {
        name:"Geroge",
        mark: "SamDU",
    },
    {
        name:"Megan",
        mark: "Oxford",
    },
    {
        name:"Tony",
        mark: "Harvard",
    },
    {
        name:"Harry",
        mark: "Oxford",
    },
    {
        name:"Justin",
        mark: "SamDU",
    },
    {
        name:"Sherin",
        mark: "Harvard",
    },
    {
        name:"Bob",
        mark: "Oxford",
    },
    {
        name:"Mike",
        mark: "SamDU",
    },
]

let count = [
    {
        University:"Harvard",
        number:0
    },
    {
        University:"Oxford",
        number:0
    },
    {
        University:"SamDU",
        number:0
    },
]




// Создайте цикл, проверяющий объекты массива Students.
// Затем вычислите в массиве count количество студентов, обучающихся в каждом университете.