const zone1 = document.querySelector('.zone-1')
const zone2 = document.querySelector('.zone-2')
const ball = document.querySelector('#ufo')

// ondragover это атрибут HTML5
// zone1.ondragover = allowDrop;
// zone2.ondragover = allowDrop;

// function allowDrop(event) {
//     event.preventDefault()
// }

// ufo.ondragstart = drag

// function drag() {
//     // Объект DataTransfer используется для хранения данных,
//     // перетаскиваемых мышью во время операции drag and drop.
//     // Он может хранить от одного до нескольких элементов данных,
//     // вне зависимости от их типа. Для получения доп. информации об операции drag and drop
//     event.dataTransfer.setData('id', event.target.id);
// }

// zone1.ondrop = drop;
// zone2.ondrop = drop;

// function drop(event) {
//     let itemId = event.dataTransfer.getData('id');
//     console.log(itemId);
//     event.target.append(document.getElementById(itemId))
// }

// ball.onmousedown = function(event) { // (1) отследить нажатие

//     ball.ondragstart = function() {
//         return false;
//     };

//   // (2) подготовить к перемещению:
//   // разместить поверх остального содержимого и в абсолютных координатах
//   ball.style.position = 'absolute';
//   ball.style.zIndex = 1000;
//   // переместим в body, чтобы мяч был точно не внутри position:relative
//   document.body.append(ball);
//   // и установим абсолютно спозиционированный мяч под курсор

//   moveAt(event.pageX, event.pageY);

//   // передвинуть мяч под координаты курсора
//   // и сдвинуть на половину ширины/высоты для центрирования
//   function moveAt(pageX, pageY) {
//     ball.style.left = pageX - ball.offsetWidth / 2 + 'px';
//     ball.style.top = pageY - ball.offsetHeight / 2 + 'px';
//   }

//   function onMouseMove(event) {
//     moveAt(event.pageX, event.pageY);
//   }

//   // (3) перемещать по экрану
//   document.addEventListener('mousemove', onMouseMove);

//   // (4) положить мяч, удалить более ненужные обработчики событий
//   ball.onmouseup = function() {
//     document.removeEventListener('mousemove', onMouseMove);
//     ball.onmouseup = null;
//   };

// };

let currentDroppable = null

ball.onmousedown = function (event) {
	let shiftX = event.clientX - ball.getBoundingClientRect().left // получаем информацию о нахождении нашего объекта 
	let shiftY = event.clientY - ball.getBoundingClientRect().top  // получаем информацию о нахождении нашего объекта 

	ball.style.position = 'absolute' //   чтобы был выше всех
	ball.style.zIndex = 1000 // чтобы был выше всех
	document.body.append(ball)

	moveAt(event.pageX, event.pageY)

	function moveAt(pageX, pageY) {
		ball.style.left = pageX - shiftX + 'px'
		ball.style.top = pageY - shiftY + 'px'
	}

	function onMouseMove(event) {
		moveAt(event.pageX, event.pageY)

		ball.hidden = true
		let elemBelow = document.elementFromPoint(event.clientX, event.clientY)
		ball.hidden = false

		if (!elemBelow) return

		let droppableBelow = elemBelow.closest('.droppable')
		if (currentDroppable != droppableBelow) {
			if (currentDroppable) {
				// null если мы были не над droppable до этого события
				// (например, над пустым пространством)
				leaveDroppable(currentDroppable)
			}
			currentDroppable = droppableBelow
			if (currentDroppable) {
				// null если мы не над droppable сейчас, во время этого события
				// (например, только что покинули droppable)
				enterDroppable(currentDroppable)
			}
		}
	}

	document.addEventListener('mousemove', onMouseMove)

	ball.onmouseup = function () {
		document.removeEventListener('mousemove', onMouseMove)
		ball.onmouseup = null
	}
}

function enterDroppable(elem) {
    console.log('полет нормальный');
    elem.classList.add('dropp')
    elem.style.background = 'orange'
    elem.style.borderRadius = '100px'
}

function leaveDroppable(elem) {
    elem.style.background = ''
    elem.style.borderRadius =       '0px'
}

ball.ondragstart = function () {
	return false
}
