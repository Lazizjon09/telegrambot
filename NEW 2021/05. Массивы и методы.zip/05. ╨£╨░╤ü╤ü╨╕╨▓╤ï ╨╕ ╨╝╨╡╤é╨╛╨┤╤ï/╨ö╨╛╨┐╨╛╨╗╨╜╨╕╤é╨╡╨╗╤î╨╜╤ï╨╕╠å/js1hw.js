//1. Получите значение «Volvo» из массива cars.

// let cars = ["Saab", "Volvo", "BMW"];


//2. Поменять первую позицию авто на "Форд".

// const cars = ["Volvo", "Jeep", "Mercedes"];


//3. Консолируйте количество элементов в массиве, используя правильное свойство Array.

// const cars = ["Volvo", "Jeep", "Mercedes"];
