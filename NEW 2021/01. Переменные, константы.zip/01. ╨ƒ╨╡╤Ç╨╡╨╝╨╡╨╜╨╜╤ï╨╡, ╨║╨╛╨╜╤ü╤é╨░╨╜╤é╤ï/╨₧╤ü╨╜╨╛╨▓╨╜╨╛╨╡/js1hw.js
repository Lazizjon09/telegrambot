// Сколько всего заработает человек за год, с такими условиями? Сложить траты и доходы в отдельные переменные `spending_total` `income_total` измеряется в процентах

// `let money = 25000`

// `let spending_total = 0
// let income_total = 0`

// `let spending1 = 4
// let spending2 = 12`

// `let income1 = 8
// let icnome2 = 14`

// `let total = 0`